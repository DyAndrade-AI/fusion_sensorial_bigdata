# Fusión Sensorial + Índice de Valor (PySpark)

Recomendador turístico: música (manual o CSV) + color (hex o imagen) -> perfil sensorial ->
destinos del dataset Rest-Mex 2025, con un control de presupuesto (valor/precio percibido).

## Ejecución (WSL / Ubuntu, dentro del venv del proyecto)
```bash
pip install pyspark Pillow            # solo si aún no los tienes
mkdir -p data/raw && cp /ruta/Rest-Mex_2025_train_clean.csv data/raw/
#   o bien: export RESTMEX_CSV=/mnt/c/Users/TU_USUARIO/ruta/Rest-Mex_2025_train_clean.csv

python -m src.build_profiles          # 1) Spark: reseñas -> data/processed/profiles.json
python -m src.evaluate --split-half   # 2) evaluación (coherencia + fiabilidad por mitades)
python -m src.main --bpm 150 --energy 0.9 --danceability 0.85 --valence 0.8 --color "#FF3300"
python -m src.main --color "#6FA8DC" --presupuesto 0.8 --solo-joyas --vista destinos
```
Salida esperada de build_profiles: `Reseñas cargadas: 208,051` y ~108 unidades (Town, Type).
